import SwiftUI

struct ContentView: View {
    
    private let obras: [ObraDeArte] = [
        ObraDeArte(
            id: UUID(),
            titulo: "Painel da Roda de Ferro",
            artista: "Poty Lazzarotto",
            ano: 1972,
            estilo: "Gravura em concreto",
            imagemNome: "poty_roda_ferro",
            descricao: "Painel loacalizado na Praça 19 de Dezembro, em Curitiba, representando cenas do cotidiano paranaense."
        ),
        ObraDeArte(
            id: UUID(),
            titulo: "Tigre Esmagando a Cobra",
            artista: "Ida Hannemann de Campos",
            ano: 1944,
            estilo: "Escultura em bronze",
            imagemNome: "oao_turin_tigre",
            descricao: "Escultura premiada no Salão Nacional de Belas Artes, localizada na Avenida Manoel Ribas, em Curitiba"
        ),
        ObraDeArte(
            id: UUID(),
            titulo: "Natureza Morta",
            artista: "Alfredo Andersen",
            ano: 1972,
            estilo: "Pintura",
            imagemNome: "ida_natureza_morta",
            descricao: "Obra pertencente ao acervo do Museu de Arte Contemporânea do Paraná, destacando a experimentação artística da autora"
        ),
        ObraDeArte(
            id: UUID(),
            titulo: "A vida do papel de bala",
            artista: "Efigênia Ramos Rolim",
            ano: 1980,
            estilo: "Escultura",
            imagemNome: "efigenia_ramos_rolim",
            descricao: "Obras que ela fez durante sua vida e está exposta em um museu na sua casa"
        )
    ]
    
    private let colunas = [GridItem(.adaptive(minimum: 150))]
    @State private var obraSelecionada: ObraDeArte? = nil

    var body: some View {
        ZStack {
            Color.white // Fundo da tela
                .ignoresSafeArea()

            NavigationStack {
                ScrollView {
                    LazyVGrid(columns: colunas, spacing: 16) {
                        ForEach(obras) { obra in
                            ObraCardView(obra: obra)
                                .onTapGesture {
                                    obraSelecionada = obra
                                }
                        }
                    }
                    .padding()
                }
                .navigationTitle("Galeria de Arte")
                .navigationDestination(isPresented: Binding(
                    get: { obraSelecionada != nil },
                    set: { if !$0 { obraSelecionada = nil } }
                )) {
                    if let obra = obraSelecionada {
                        DetalhesObraView(obra: obra)
                    }
                }
            }
        }
    }
}

struct ObraCardView: View {
    let obra: ObraDeArte

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(obra.imagemNome)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity, minHeight: 150)
                .background(Color.blue.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            
            Text(obra.titulo)
                .font(.headline)
                .lineLimit(2)
                .multilineTextAlignment(.leading)

            Text(obra.artista)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .lineLimit(1)
        }
        .padding()
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
    }
}

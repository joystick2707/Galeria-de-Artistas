//
//  Somativo_SwiftUIApp.swift
//  Somativo SwiftUI
//
//  Created by Bryan Strey on 20/05/25.
//

import SwiftUI

@main
struct Somativo_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
